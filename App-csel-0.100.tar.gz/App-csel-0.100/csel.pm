package App::csel ;  
our $VERSION = '0.100' ; 
our $DATE = '2021-06-07T01:10+09:00' ; 

=encoding utf8

=head1 NAME

App::csel

=head1 SYNOPSIS

This module provides a Unix-like command `F<csel>'. 
It proves easier interface than AWK by using -p, -d, -h, -t options of `csel'.

=head1 DESCRIPTION



=head1 SEE ALSO


=cut

1 ;
